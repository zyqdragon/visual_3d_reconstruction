import gradio as gr
import os


def load_mesh(mesh_file_name):
    return mesh_file_name

demo = gr.Interface(
    fn=load_mesh,
    inputs=gr.Model3D(clear_color=[0.0, 0.0, 0.0, 0.0],  label="3D Model"),
    #outputs=gr.Model3D(clear_color=[0.0, 0.0, 0.0, 0.0],  label="x3D Model"),
    outputs=[]
    #examples=[[os.path.join(os.path.dirname(__file__), "./result.glb")],],
)

if __name__ == "__main__":
    demo.launch()
#https://blog.csdn.net/qq_41667743/article/details/131605897
